original = imread('football.jpg');
se = strel('disk', 7);

subplot(3, 2, 1);
imshow(original);

subplot(3, 2, 3);
imshow(imopen(original, se));

subplot(3, 2, 4);
imshow(imclose(original, se));

subplot(3, 2, 5);
imshow(imerode(original, se));

subplot(3, 2, 6);
imshow(imdilate(original, se));

gray = rgb2gray(original);
subplot(3, 2, 2);
imshowpair(gray, histeq(gray), 'montage');