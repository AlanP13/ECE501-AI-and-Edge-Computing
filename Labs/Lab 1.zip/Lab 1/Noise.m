I = imread('coins.png');
J = imnoise(I,'gaussian',0,0.01);
imshow(J)
imwrite(J,'coinsblur2.png')