I = imread('pears.png');
I = rgb2gray(I);
imshow(I)
BW1 = edge(I,'Sobel');
BW2 = edge(I,'Roberts');
imshowpair(BW1,BW2,'montage')