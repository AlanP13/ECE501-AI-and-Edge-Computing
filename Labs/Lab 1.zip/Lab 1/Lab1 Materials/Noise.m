I = imread('image-segmentation-example.jpg');
J = imnoise(I,'gaussian',0,0.01);
imshow(J)
imwrite(J,'image-segmentation-example-figure2.png')